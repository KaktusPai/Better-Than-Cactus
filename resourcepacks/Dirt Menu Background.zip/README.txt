Dirt Menu Background

Returns dirt menu background without using Programmer Art

v1.3 • -24w13a+ by Hexagonal

---

PACK VERSION: 1.3

MC VERSION: 13w24a-24w13a upwards (literally all of them)

PROJECT: Dirt Menu Background ( https://modrinth.com/resourcepack/dirt-menu-background )

CREATOR: Hexagonal ( https://modrinth.com/user/Hexagonl )

---

LATEST CHANGELOG

Hotfix update

### Bug Fixes
- `pack.mcmeta` now *actually* shows pack as compatible with all versions of Minecraft


     [ Full changelog on Modrinth ]( https://modrinth.com/resourcepack/dirt-menu-background/version/1.3 )
[ View all changelogs on Modrinth ]( https://modrinth.com/resourcepack/dirt-menu-background/changelog )

---

// Thank you for using my first uploaded pack! Perhaps I'll start uploading some of my others lol
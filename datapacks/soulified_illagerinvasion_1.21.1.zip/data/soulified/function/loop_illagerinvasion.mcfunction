# Illager Invasion Mod Entities - Enhanced illager variants
execute as @e[type=illagerinvasion:alchemist,tag=!not_mob1,sort=random] at @s run function soulified:alchemist
execute as @e[type=illagerinvasion:archivist,tag=!not_mob1,sort=random] at @s run function soulified:archivist
execute as @e[type=illagerinvasion:basher,tag=!not_mob1,sort=random] at @s run function soulified:basher
execute as @e[type=illagerinvasion:firecaller,tag=!not_mob1,sort=random] at @s run function soulified:firecaller
execute as @e[type=illagerinvasion:inquisitor,tag=!not_mob1,sort=random] at @s run function soulified:inquisitor
execute as @e[type=illagerinvasion:invoker,tag=!not_mob1,sort=random] at @s run function soulified:invoker
execute as @e[type=illagerinvasion:marauder,tag=!not_mob1,sort=random] at @s run function soulified:marauder
execute as @e[type=illagerinvasion:necromancer,tag=!not_mob1,sort=random] at @s run function soulified:necromancer
execute as @e[type=illagerinvasion:provoker,tag=!not_mob1,sort=random] at @s run function soulified:provoker
execute as @e[type=illagerinvasion:sorcerer,tag=!not_mob1,sort=random] at @s run function soulified:sorcerer
execute as @e[type=illagerinvasion:surrendered,tag=!not_mob1,sort=random] at @s run function soulified:surrendered

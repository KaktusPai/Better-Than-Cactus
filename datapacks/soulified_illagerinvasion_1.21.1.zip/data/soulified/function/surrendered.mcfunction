# Surrendered - Tier 1 IllagerInvasion Mob (Dark Souls Overhaul)
# Base Stats: 24 HP → 30 HP (+25%)

# Increase max health by 25%
attribute @s minecraft:generic.max_health base set 30
data modify entity @s Health set value 30f

# Effects: Strength I, Resistance I (weakened illager)
effect give @s minecraft:strength 99999 0
effect give @s minecraft:resistance 99999 0

tag @s add not_mob1
scoreboard players add count_mobs soulified 1
execute if score count_mobs soulified matches 1.. run scoreboard players set count_mobs soulified 0

# Firecaller - Tier 3 IllagerInvasion Mob (Dark Souls Overhaul)
# Base Stats: 24 HP → 50 HP (+108%)

# Increase max health by 108%
attribute @s minecraft:generic.max_health base set 50
data modify entity @s Health set value 50f

# Effects: Strength III, Speed II, Resistance II, Fire Resistance II (fire mage)
effect give @s minecraft:strength 99999 2
effect give @s minecraft:speed 99999 1
effect give @s minecraft:resistance 99999 1
effect give @s minecraft:fire_resistance 99999 1

tag @s add not_mob1
scoreboard players add count_mobs soulified 1
execute if score count_mobs soulified matches 1.. run scoreboard players set count_mobs soulified 0

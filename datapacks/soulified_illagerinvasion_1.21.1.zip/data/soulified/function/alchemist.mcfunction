# Alchemist - Tier 2 IllagerInvasion Mob (Dark Souls Overhaul)
# Base Stats: 24 HP → 45 HP (+88%)

# Increase max health by 88%
attribute @s minecraft:generic.max_health base set 45
data modify entity @s Health set value 45f

# Effects: Strength II, Speed I, Resistance II, Fire Resistance II (potion thrower)
effect give @s minecraft:strength 99999 1
effect give @s minecraft:speed 99999 0
effect give @s minecraft:resistance 99999 1
effect give @s minecraft:fire_resistance 99999 1

tag @s add not_mob1
scoreboard players add count_mobs soulified 1
execute if score count_mobs soulified matches 1.. run scoreboard players set count_mobs soulified 0

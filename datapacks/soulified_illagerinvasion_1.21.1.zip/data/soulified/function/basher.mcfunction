# Basher - Tier 3 IllagerInvasion Mob (Dark Souls Overhaul)
# Base Stats: 24 HP → 55 HP (+129%)

# Increase max health by 129%
attribute @s minecraft:generic.max_health base set 55
data modify entity @s Health set value 55f

# Effects: Strength III (shield bash), Speed II, Resistance III (shield bearer)
effect give @s minecraft:strength 99999 2
effect give @s minecraft:speed 99999 1
effect give @s minecraft:resistance 99999 2

tag @s add not_mob1
scoreboard players add count_mobs soulified 1
execute if score count_mobs soulified matches 1.. run scoreboard players set count_mobs soulified 0

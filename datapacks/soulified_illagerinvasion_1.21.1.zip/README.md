# 🌑 SOULIFIED ILLAGER INVASION

Dark Souls difficulty addon for **Illager Invasion** mod. 11 elite illager variants with Tier 2-3 buffs.

---

## ⚠️ REQUIREMENTS

**Both required:**
1. **Illager Invasion Mod** (Forge/NeoForge 1.21.1)
2. **Soulified Vanilla** (base datapack - required)

---

## ⚔️ WHAT IT DOES

**11 Illager Variants Enhanced:**

### 💀 **Elite Illagers (Tier 2-3)**
- **Invoker** - Strength III, Resistance II, Speed I (boss spellcaster)
- **Necromancer** - Strength III, Resistance II (summons undead)
- **Inquisitor** - Strength III, Resistance II (fire specialist)
- **Alchemist** - Strength II, Resistance I (potion thrower)
- **Firecaller** - Strength II, Resistance II (flame magic)
- **Sorcerer** - Strength II, Resistance I (arcane caster)
- **Archivist** - Strength II, Resistance I (support caster)
- **Provoker** - Strength II, Resistance I (summoner)
- **Basher** - Strength III, Resistance II (heavy melee)
- **Marauder** - Strength II, Resistance I, Speed I (fast raider)
- **Surrendered** - Strength I, Resistance I (weakened illager)

All illagers enhanced for late-game raid difficulty.

---

## 📥 INSTALLATION

1. Install Illager Invasion mod in mods folder
2. Install Soulified Vanilla in datapacks folder
3. Place `soulified_illagerinvasion` in datapacks folder
4. Run `/reload` in-game

---

## 🐛 TROUBLESHOOTING

**Illagers not buffed?** Verify Illager Invasion mod is installed
**Still too easy?** Invoker and Inquisitor are boss-tier
**Works on servers?** Yes, install mod + both datapacks

---

**Face the raid! 💀⚔️**
